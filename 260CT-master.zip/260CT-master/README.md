# 260CT
Java Software Engenering

First Feedback:
 Separate Name: First and last name
 Separate address:  Address, City, Country, PostCode
 Add date of birth.
 Add Contact of emergency. (neast of lein)
 Do a validation for email.
 Separate Phone Number: Home and Mobile.
 Add Position and deparment Atribute
 
 Check if they sure about the changes when someone deletes/updates the data.


MAnageres. intructors and Advisors

java db password and id: manager
//call SYSCS_UTIL.SYSCS_SET_DATABASE_PROPERTY('derby.user.john', 'johnsnewpassword') for change passowrd
